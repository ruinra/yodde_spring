package com.yodde.evaluationModel;

public interface EvaluationDao {
	EvaluationDto evaluationCheck(String email, int ReviewId);
}
